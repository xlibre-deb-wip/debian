#ifndef XSERVER_XVDISP_H
#define XSERVER_XVDISP_H

extern void XineramifyXv(void);
extern int xvUseXinerama;

#endif /* XSERVER_XVDISP_H */
